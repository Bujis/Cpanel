const fs = require('fs')
const chalk = require('chalk')
// EDIT DISINI MELSAK ENC
global.owner = ['62895391551260'] // NOMOR OWNER 
global.packname = 'MELSAK' // NAMA KAMU DISINI
global.author = 'DIANTO'//  ISI NAMA OWNER
global.domain = 'https://diantoratna.mydns.my.id' // TULIS DOMAIN KAMU
global.apikey = 'ptla_iXK5IUFZxJ0jXO0hzzBeTDIgY9HuUCD3QLYci7b8vx8' // APIKEY PLTA KAMU
global.capikey = 'ptlc_wQmDCD17pfEV87bp6ZcmkTXkVfaHYZJm5lpmke2qt8W' // APIKEY PTLC KAMU 
// ISI API& CPI KEY SRV ADMIN DI SATUIN ISI KAYAK DI ATAS
global.domainadmin = 'https://diantoratna.mydns.my.id'
global.apiadmin = 'ptla_iXK5IUFZxJ0jXO0hzzBeTDIgY9HuUCD3QLYci7b8vx8'
global.cpiadmin = 'ptlc_wQmDCD17pfEV87bp6ZcmkTXkVfaHYZJm5lpmke2qt8W'
global.eggsnya = '15' // ID EGGS KAMU
global.location = '1' // ID LOCASI LU

global.qrisdana = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg'}
global.qrisgopay = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg'}
global.jasapanel = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg'}
global.menu = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg'}
global.anjay = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg'}
global.qrisallpay = { url: 'https://telegra.ph/file/a956746589a2084cc6ea5.jpg' }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})